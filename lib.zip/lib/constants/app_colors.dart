import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF4CAF50);
  static const black = Colors.black;
  static const white = Colors.white;
  static const grey = Colors.grey;
}
