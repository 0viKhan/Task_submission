import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controller/alarm_controller.dart';

class AddAlarmBottomSheet extends StatelessWidget {
  const AddAlarmBottomSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: ElevatedButton(
          onPressed: () async {
            final time = await showTimePicker(
              context: context,
              initialTime: TimeOfDay.now(),
            );

            if (time == null) return;

            final now = DateTime.now();
            final dateTime = DateTime(
              now.year,
              now.month,
              now.day,
              time.hour,
              time.minute,
            );

            context.read<AlarmController>().addAlarm(dateTime);
            Navigator.pop(context);
          },
          child: const Text("Pick Time"),
        ),
      ),
    );
  }
}
