class UserLocationModel {
  final double latitude;
  final double longitude;

  const UserLocationModel({
    required this.latitude,
    required this.longitude,
  });
}
